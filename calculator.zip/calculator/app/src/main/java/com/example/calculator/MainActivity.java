package com.example.calculator;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends Activity implements View.OnClickListener {
    EditText input1;
    EditText input2;
    Button addition;
    Button subtraction;
    Button multiplication;
    Button division;
    TextView tvResult;
    String opera = " ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input1 = (EditText) findViewById(R.id.etNum1);
        input2 = (EditText) findViewById(R.id.etNum2);
        addition = (Button) findViewById(R.id.btnAdd);
        subtraction =(Button) findViewById(R.id.btnSub);
        multiplication = (Button)findViewById(R.id.btnMult);
        division = (Button)findViewById(R.id.btnDiv);
        tvResult = (TextView) findViewById(R.id.tvResult);
        addition.setOnClickListener(this);
        subtraction.setOnClickListener(this);
        multiplication.setOnClickListener(this);
        division.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        float num1 = 0;
        float num2 = 0;
        float result = 0;
        if (TextUtils.isEmpty(input1.getText().toString()) ||
                TextUtils.isEmpty(input2.getText().toString()))
            return;
        num1 = Float.parseFloat(input1.getText().toString());
        num2 = Float.parseFloat(input2.getText().toString());
        int id = v.getId();
        if(id==R.id.btnAdd){
            opera = "+";
            result = num1 + num2;
        }
        else if(id==R.id.btnSub){
            opera = "-";
            result = num1 - num2;
        }
        else if(id==R.id.btnMult){
            opera = "*";
            result = num1 * num2;
        }
        else if(id==R.id.btnDiv){
            opera = "/";
            result = num1 / num2;
        }
        else
        {
            Toast.makeText(getApplicationContext(),"invalid input",Toast.LENGTH_LONG).show();
        }
        tvResult.setText(num1 + " " + opera + " " + num2 + " = " + result);
    }
}
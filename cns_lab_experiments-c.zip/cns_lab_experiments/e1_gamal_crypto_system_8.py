#ElGamal Cryptosystem
import random

def power(base, exp, mod):
    return pow(base, exp, mod)

def encrypt(p, g, y, message):
    k = random.randint(1, p - 2)  # random ephemeral key
    a = power(g, k, p)
    b = [(m * power(y, k, p)) % p for m in message]
    return a, b

def decrypt(p, x, a, b):
    a_pow_x = power(a, x, p)
    a_inv = power(a_pow_x, -1, p)  # Modular inverse using pow with -1
    return [(c * a_inv) % p for c in b]

def to_int_list(text):
    return [ord(char) for char in text]

def to_text(int_list):
    return ''.join(chr(i) for i in int_list)

# Dynamic Input
p = int(input("Enter a large prime number p: "))
g = int(input("Enter a primitive root modulo p (g): "))
x = int(input("Enter private key x (1 < x < p): "))
message = input("Enter the message to encrypt: ")

# Public key
y = power(g, x, p)

msg_nums = to_int_list(message)
a, b = encrypt(p, g, y, msg_nums)
decrypted_nums = decrypt(p, x, a, b)

print("Public key (p, g, y):", (p, g, y))
print("Cipher text (a, b):", (a, b))
print("Decrypted message:", to_text(decrypted_nums))

# Example Input:
# Enter a large prime number p: 23
# Enter a primitive root modulo p (g): 5
# Enter private key x (1 < x < p): 6
# Enter the message to encrypt: hi
# Output:
# Public key (p, g, y): (23, 5, 8)
# Cipher text (a, b): (10, [18, 20])
# Decrypted message: hi

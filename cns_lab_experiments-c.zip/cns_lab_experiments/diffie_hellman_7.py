#Diffie-Hellman key exchange
def power(base, exp, mod):
    return pow(base, exp, mod)

# Dynamic Input
p = int(input("Enter a prime number p: "))         # Public prime
g = int(input("Enter a primitive root g: "))       # Public base
a = int(input("Enter Alice's private key (a): "))  # Private key of Alice
b = int(input("Enter Bob's private key (b): "))    # Private key of Bob

# Public values sent over the channel
A = power(g, a, p)  # g^a mod p
B = power(g, b, p)  # g^b mod p

# Shared secret keys
secret_key_alice = power(B, a, p)  # B^a mod p
secret_key_bob   = power(A, b, p)  # A^b mod p

print("Alice sends:", A)
print("Bob sends:", B)
print("Shared Secret (Alice):", secret_key_alice)
print("Shared Secret (Bob):", secret_key_bob)

# Example Input:
# Enter a prime number p: 23
# Enter a primitive root g: 5
# Enter Alice's private key (a): 6
# Enter Bob's private key (b): 15
# Output:
# Alice sends: 8
# Bob sends: 2
# Shared Secret (Alice): 2
# Shared Secret (Bob): 2

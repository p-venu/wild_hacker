#one time padding
import random
import string

def generate_key(length):
    return ''.join(random.choice(string.ascii_uppercase) for _ in range(length))

def otp_encrypt(plaintext, key):
    plaintext = plaintext.upper().replace(" ", "")
    ciphertext = ""

    for p, k in zip(plaintext, key):
        p_val = ord(p) - ord('A')
        k_val = ord(k) - ord('A')
        c_val = (p_val + k_val) % 26
        ciphertext += chr(c_val + ord('A'))
    
    return ciphertext

def otp_decrypt(ciphertext, key):
    decrypted = ""

    for c, k in zip(ciphertext, key):
        c_val = ord(c) - ord('A')
        k_val = ord(k) - ord('A')
        p_val = (c_val - k_val + 26) % 26
        decrypted += chr(p_val + ord('A'))
    
    return decrypted


# 🎯 Dynamic Input
plaintext = input("Enter the message to encrypt (letters only): ").upper().replace(" ", "")
key = generate_key(len(plaintext))

encrypted = otp_encrypt(plaintext, key)
decrypted = otp_decrypt(encrypted, key)

# 🖨️ Outputs
print("Random Key Used:", key)
print("Encrypted:", encrypted)
print("Decrypted:", decrypted)

# Output:
# Enter the message to encrypt: HELLO
# Output (key will vary)
# Random Key Used: KZPQM
# Encrypted: RDDSZ
# Decrypted: HELLO

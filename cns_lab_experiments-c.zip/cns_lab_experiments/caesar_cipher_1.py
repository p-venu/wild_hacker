#caesar cipher
def caesar_cipher(text, shift, mode='encrypt'):
    result = ""

    if mode == 'decrypt':
        shift = -shift  # Reverse the shift for decryption

    for char in text:
        if char.isalpha():
            offset = 65 if char.isupper() else 97
            shifted_char = chr((ord(char) - offset + shift) % 26 + offset)
            result += shifted_char
        else:
            result += char
    return result


# 🔁 Dynamic input
message = input("Enter the message: ")
shift = int(input("Enter the shift value: "))

# Encrypt
encrypted = caesar_cipher(message, shift, mode='encrypt')
print("Encrypted:", encrypted)

# Decrypt
decrypted = caesar_cipher(encrypted, shift, mode='decrypt')
print("Decrypted:", decrypted)

# Example Input:
# Enter the message: Hello, World!
# Enter the shift value: 3
# Output:
# Encrypted: Khoor, Zruog!
# Decrypted: Hello, World!

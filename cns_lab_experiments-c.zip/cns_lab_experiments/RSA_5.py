#Rivest–Shamir–Adleman(rsa)
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    for d in range(1, phi):
        if (e * d) % phi == 1:
            return d
    return None

def encrypt(message, e, n):
    return [(ord(char) ** e) % n for char in message]

def decrypt(cipher, d, n):
    return ''.join([chr((char ** d) % n) for char in cipher])

# Dynamic Input
p = int(input("Enter a prime number p: "))
q = int(input("Enter a prime number q: "))
message = input("Enter the message to encrypt: ")

n = p * q
phi = (p - 1) * (q - 1)

# Choose e
e = None
for i in range(2, phi):
    if gcd(i, phi) == 1:
        e = i
        break

d = mod_inverse(e, phi)

ciphertext = encrypt(message, e, n)
decrypted_text = decrypt(ciphertext, d, n)

print("Encrypted:", ciphertext)
print("Decrypted:", decrypted_text)

# Example Input:
# Enter a prime number p: 3
# Enter a prime number q: 11
# Enter the message to encrypt: hi
# Output:
# Encrypted: [5, 9]
# Decrypted: hi

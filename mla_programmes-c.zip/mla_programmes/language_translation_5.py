# language translation using machine learning algorithm

# pip install transformers sentencepiece
# pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
# pip install sacremoses

from transformers import MarianMTModel, MarianTokenizer

# Model name for English to Hindi
model_name = 'Helsinki-NLP/opus-mt-en-hi'

# Load tokenizer and model
tokenizer = MarianTokenizer.from_pretrained(model_name)
model = MarianMTModel.from_pretrained(model_name)

# Text to translate
text = "how are you"

# Tokenize and translate
tokens = tokenizer([text], return_tensors="pt", padding=True)
translated = model.generate(**tokens)

# Decode output
translated_text = tokenizer.decode(translated[0], skip_special_tokens=True)
print("Translated text:", translated_text)

# Output:
# Translated text: तुम कैसे हो

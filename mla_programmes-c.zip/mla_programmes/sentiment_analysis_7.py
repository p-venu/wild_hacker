# sentiment analysis

# pip install transformers
# pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

from transformers import pipeline

# Load sentiment-analysis pipeline
classifier = pipeline("sentiment-analysis")

# Example text
text = "very good mood"

# Get prediction
result = classifier(text)[0]
print(f"Label: {result['label']}, Score: {result['score']:.2f}")

# Output:
# Label: POSITIVE, Score: 0.99

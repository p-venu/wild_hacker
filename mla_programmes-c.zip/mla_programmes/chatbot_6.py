# chat bot

# No external modules required

def chatbot_response(user_input):
    user_input = user_input.lower()

    if "hello" in user_input or "hi" in user_input:
        return "Hello there! How can I help you?"
    elif "your name" in user_input:
        return "I'm a simple chatbot!"
    elif "how are you" in user_input:
        return "I'm doing great. Thanks for asking!"
    elif "bye" in user_input:
        return "Goodbye! Have a great day."
    else:
        return "I'm not sure how to respond to that."

# Chat loop
print("Chatbot: Hello! Type 'bye' to end the chat.")
while True:
    user_input = input("You: ")
    response = chatbot_response(user_input)
    print("Chatbot:", response)
    if "bye" in user_input.lower():
        break

# Output:
# Chatbot: Hello! Type 'bye' to end the chat.
# You: hi
# Chatbot: Hello there! How can I help you?
# You: how are you
# Chatbot: I'm doing great. Thanks for asking!
# You: what's your name
# Chatbot: I'm not sure how to respond to that.
# You: bye
# Chatbot: Goodbye! Have a great day.

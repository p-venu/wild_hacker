package com.example.graphical;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new MyView(this));
    }

    private class MyView extends View {
        public MyView(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Paint paint = new Paint();
            paint.setTextSize(40);

            // Draw Circle
            paint.setColor(Color.BLACK);
            canvas.drawText("Circle", 52, 30, paint);
            paint.setColor(Color.GREEN);
            canvas.drawCircle(100, 150, 100, paint);

            // Draw Rectangle
            paint.setColor(Color.BLACK);
            canvas.drawText("Rectangle", 255, 30, paint);
            paint.setColor(Color.YELLOW);
            canvas.drawRect(250, 50, 400, 350, paint);

            // Draw Square
            paint.setColor(Color.BLACK);
            canvas.drawText("SQUARE", 55, 430, paint);
            paint.setColor(Color.BLUE);
            canvas.drawRect(50, 450, 150, 550, paint);

            // Draw Line
            paint.setColor(Color.BLACK);
            canvas.drawText("LINE", 255, 430, paint);
            paint.setColor(Color.CYAN);
            canvas.drawLine(250, 500, 350, 500, paint);
        }
    }
}

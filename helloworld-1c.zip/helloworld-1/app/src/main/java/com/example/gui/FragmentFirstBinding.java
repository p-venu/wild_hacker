package com.example.gui;

public interface FragmentFirstBinding {
}

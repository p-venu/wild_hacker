package com.example.audio;
import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSION_CODE = 100;
    private MediaRecorder mediaRecorder;
    private String audioFilePath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Request necessary permissions
        requestPermissions();
        // Set the path to store the audio file
        audioFilePath = getExternalCacheDir().getAbsolutePath() + "/audio.3gp";
    }
    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                        PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new
                    String[]{Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION_CODE);
        }
    }
    public void startRecording(View view) {
        try {
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setOutputFile(audioFilePath);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.prepare();
            mediaRecorder.start();
            // Toggle visibility of buttons
            Button startButton = findViewById(R.id.startRecordingButton);
            Button stopButton = findViewById(R.id.stopRecordingButton);
            startButton.setVisibility(View.GONE);
            stopButton.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void stopRecording(View view) {
        mediaRecorder.stop();
        mediaRecorder.release();
        mediaRecorder = null;
        // Toggle visibility of buttons
        Button startButton = findViewById(R.id.startRecordingButton);
        Button stopButton = findViewById(R.id.stopRecordingButton);
        startButton.setVisibility(View.VISIBLE);
        stopButton.setVisibility(View.GONE);
        Toast.makeText(this, "Recording stopped", Toast.LENGTH_SHORT).show();
    }
}
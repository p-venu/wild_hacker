package com.example.gui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    float font = 24;
    int i = 1;
    int fontType = Typeface.NORMAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView t1 = findViewById(R.id.textView1);
        Button b1 = findViewById(R.id.button1);
        Button b2 = findViewById(R.id.button2);
        Button b3 = findViewById(R.id.button3);

        b1.setOnClickListener(view -> {
            t1.setTextSize(font);
            font += 4;
            if (font > 40) font = 20;
        });

        b2.setOnClickListener(view -> {
            switch (i) {
                case 1:
                    t1.setTextColor(Color.BLUE);
                    break;
                case 2:
                    t1.setTextColor(Color.GREEN);
                    break;
                case 3:
                    t1.setTextColor(Color.RED);
                    break;
                case 4:
                    t1.setTextColor(Color.parseColor("#F00000"));
                    break;
            }
            i++;
            if (i == 5) i = 1;
        });

        b3.setOnClickListener(view -> {
            switch (fontType) {
                case Typeface.NORMAL:
                    t1.setTypeface(null, Typeface.BOLD);
                    fontType = Typeface.BOLD;
                    break;
                case Typeface.BOLD:
                    t1.setTypeface(null, Typeface.ITALIC);
                    fontType = Typeface.ITALIC;
                    break;
                case Typeface.ITALIC:
                    t1.setTypeface(null, Typeface.BOLD_ITALIC);
                    fontType = Typeface.BOLD_ITALIC;
                    break;
                case Typeface.BOLD_ITALIC:
                    t1.setTypeface(null, Typeface.NORMAL);
                    fontType = Typeface.NORMAL;
                    break;
            }
        });
    }
}

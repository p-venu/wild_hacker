#controlling brightness of led using pwm 4


import RPi.GPIO as GPIO
import time

ledPin = 18

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(ledPin, GPIO.OUT)

pwm = GPIO.PWM(ledPin, 100)  # Set PWM on ledPin at 100Hz
pwm.start(0)  # Start PWM with 0% duty cycle

try:
    while True:
        # Increasing brightness
        for i in range(100):
            pwm.ChangeDutyCycle(i)
            time.sleep(0.2)
        
        # Decreasing brightness
        for i in range(100, 0, -1):
            pwm.ChangeDutyCycle(i)
            time.sleep(0.2)

except KeyboardInterrupt:
    pwm.stop()
    print("\nExiting program\n")
    GPIO.cleanup()
    exit()

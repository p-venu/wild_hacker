print("Enter one of the following colours:")
print("Red | Green | Blue")
print("Magenta | Yellow | Cyan")
print("White | OFF")

colour = input("Enter the colour: ")
#blink led 2



import RPi.GPIO as GPIO
import time

# Set GPIO mode
GPIO.setmode(GPIO.BCM)

# Define LED pins
ledpinOne = 12
ledpinTwo = 13

# Set up both pins as output
GPIO.setup(ledpinOne, GPIO.OUT)
GPIO.setup(ledpinTwo, GPIO.OUT)

try:
    while True:
        GPIO.output(ledpinOne, GPIO.HIGH)  # Turn LED1 ON
        GPIO.output(ledpinTwo, GPIO.LOW)   # Turn LED2 OFF
        time.sleep(1)

        GPIO.output(ledpinOne, GPIO.LOW)   # Turn LED1 OFF
        GPIO.output(ledpinTwo, GPIO.HIGH)  # Turn LED2 ON
        time.sleep(1)

except KeyboardInterrupt:
    print("\nProgram stopped by user\n")
    GPIO.cleanup()
    exit()

# Output:
# LED1 and LED2 will blink alternately every 1 second until Ctrl+C is pressed.

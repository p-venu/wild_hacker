#control relay using ultrasonic sensors 5


import RPi.GPIO as GPIO
import time

trigPin = 15
echoPin = 14
relayPin = 26

def distance():
    GPIO.output(trigPin, True)
    time.sleep(0.00001)
    GPIO.output(trigPin, False)

    while GPIO.input(echoPin) == 0:
        pulse_start = time.time()

    while GPIO.input(echoPin) == 1:
        pulse_end = time.time()

    try:
        pulse_duration = pulse_end - pulse_start
    except:
        print("Calibrating")
        return 2000

    distance = pulse_duration * 17150
    distance = round(distance + 1.15, 2)

    return distance

def main():
    GPIO.setmode(GPIO.BCM)

    # Set GPIO direction (IN / OUT)
    GPIO.setup(relayPin, GPIO.OUT)
    GPIO.setup(trigPin, GPIO.OUT)
    GPIO.setup(echoPin, GPIO.IN)

    prevDist = 10  # Arbitrary initial value

    try:
        while True:
            dist = distance()
            print("Measured Distance = {} cm".format(dist))

            if abs(dist - prevDist) > 50:
                prevDist = dist
                continue

            if dist > 50:
                GPIO.output(relayPin, GPIO.HIGH)
            else:
                GPIO.output(relayPin, GPIO.LOW)

            time.sleep(0.5)
            prevDist = dist

    except KeyboardInterrupt:
        print("\nExiting program\n")
        GPIO.cleanup()
        exit()

main()

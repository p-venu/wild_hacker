#publishing dht sensor value to web page using mqtt 7


import RPi.GPIO as GPIO
import paho.mqtt.client as paho
import adafruit_dht
import time
import board

publishTopic = "IOTIF/RPI/DHT"

# Initialize DHT11 sensor on GPIO pin 26
dht_sensor = adafruit_dht.DHT11(board.D26)

# MQTT connection callback
def on_connect(client, userdata, flags, rc):
    print("Connected with result code", str(rc))

# Setup MQTT client
client = paho.Client()
client.connect('broker.hivemq.com')
client.on_connect = on_connect

# Main loop
try:
    while True:
        try:
            temperature = dht_sensor.temperature
            humidity = dht_sensor.humidity
            msg = "{},{}".format(humidity, temperature)
            client.publish(publishTopic, msg)
        except RuntimeError as e:
            print(f"Reading error: {e}, Retry")
        
        client.loop()
        time.sleep(5)

except KeyboardInterrupt:
    print("\nExiting the program\n")
    GPIO.cleanup()
    exit()
